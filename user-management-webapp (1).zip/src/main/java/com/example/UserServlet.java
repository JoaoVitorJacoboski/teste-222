
package com.example;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserServlet extends HttpServlet {
    private String dbUrl;
    private String dbUser;
    private String dbPassword;

    @Override
    public void init() throws ServletException {
        super.init();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("db.properties")) {
            Properties props = new Properties();
            if (in == null) {
                throw new ServletException("db.properties not found in classpath");
            }
            props.load(in);
            dbUrl = props.getProperty("db.url");
            dbUser = props.getProperty("db.user");
            dbPassword = props.getProperty("db.password");
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    // POST -> create user
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String phone = req.getParameter("phone");
        String info = req.getParameter("info");
        if (name == null || name.isBlank()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{"error":"name is required"}");
            return;
        }
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("INSERT INTO users (name, phone, info) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, info);
            int affected = ps.executeUpdate();
            if (affected == 0) {
                resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                resp.getWriter().write("{\"error\":\"insert failed\"}");
                return;
            }
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.getWriter().write("{" + "\"id\":" + id + ",\"name\":\"" + escapeJson(name) + "\",\"phone\":\"" + escapeJson(phone) + "\",\"info\":\"" + escapeJson(info) + "\"}"); 
                }
            }
        } catch (SQLException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    // GET -> get user by id or search by name or return all
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("id");
        String search = req.getParameter("search");
        resp.setContentType("application/json;charset=UTF-8");
        try (Connection c = getConnection()) {
            if (idParam != null) {
                int id = Integer.parseInt(idParam);
                try (PreparedStatement ps = c.prepareStatement("SELECT id, name, phone, info FROM users WHERE id = ?")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            resp.getWriter().write(userToJson(rs));
                            return;
                        } else {
                            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                            resp.getWriter().write("{\"error\":\"not found\"}");
                            return;
                        }
                    }
                }
            } else {
                String sql = "SELECT id, name, phone, info FROM users";
                if (search != null && !search.isBlank()) {
                    sql += " WHERE name LIKE ?";
                    try (PreparedStatement ps = c.prepareStatement(sql)) {
                        ps.setString(1, "%" + search + "%");
                        try (ResultSet rs = ps.executeQuery()) {
                            List<String> rows = new ArrayList<>();
                            while (rs.next()) rows.add(userToJsonString(rs));
                            resp.getWriter().write("[" + String.join(",", rows) + "]");
                            return;
                        }
                    }
                } else {
                    try (PreparedStatement ps = c.prepareStatement(sql);
                         ResultSet rs = ps.executeQuery()) {
                        List<String> rows = new ArrayList<>();
                        while (rs.next()) rows.add(userToJsonString(rs));
                        resp.getWriter().write("[" + String.join(",", rows) + "]");
                        return;
                    }
                }
            }
        } catch (SQLException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    // PUT -> update user
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // parse form-style body
        String body = req.getReader().lines().reduce("", (a,b)->a+b);
        // Expecting body like: name=...&phone=...&info=...&id=...
        java.util.Map<String,String> params = parseUrlEncoded(body);
        String idStr = params.get("id");
        if (idStr == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"id required\"}");
            return;
        }
        int id = Integer.parseInt(idStr);
        String name = params.get("name"); String phone = params.get("phone"); String info = params.get("info");
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET name=?, phone=?, info=? WHERE id=?")) {
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, info);
            ps.setInt(4, id);
            int updated = ps.executeUpdate();
            if (updated == 0) {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                resp.getWriter().write("{\"error\":\"not found\"}");
                return;
            }
            resp.getWriter().write("{\"status\":\"ok\"}");
        } catch (SQLException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    // DELETE -> delete user by id
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idParam = req.getParameter("id");
        if (idParam == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"error\":\"id required\"}");
            return;
        }
        int id = Integer.parseInt(idParam);
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM users WHERE id = ?")) {
            ps.setInt(1, id);
            int deleted = ps.executeUpdate();
            if (deleted == 0) {
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                resp.getWriter().write("{\"error\":\"not found\"}");
                return;
            }
            resp.getWriter().write("{\"status\":\"deleted\"}");
        } catch (SQLException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    private String userToJson(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String name = rs.getString("name"); String phone = rs.getString("phone"); String info = rs.getString("info");
        return "{" + "\"id\":"+id+",\"name\":\""+escapeJson(name)+"\",\"phone\":\""+escapeJson(phone)+"\",\"info\":\""+escapeJson(info)+"\"}";
    }

    private String userToJsonString(ResultSet rs) throws SQLException {
        return userToJson(rs);
    }

    private String escapeJson(String s) {
        if (s==null) return "";
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");
    }

    private java.util.Map<String,String> parseUrlEncoded(String body) throws UnsupportedEncodingException {
        java.util.Map<String,String> map = new java.util.HashMap<>();
        if (body==null || body.isBlank()) return map;
        String[] parts = body.split("&");
        for (String p: parts) {
            String[] kv = p.split("=",2);
            String k = java.net.URLDecoder.decode(kv[0], "UTF-8");
            String v = kv.length>1 ? java.net.URLDecoder.decode(kv[1], "UTF-8") : "";
            map.put(k,v);
        }
        return map;
    }
}
