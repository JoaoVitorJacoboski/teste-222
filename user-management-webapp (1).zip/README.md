
# User Management Webapp (Java Servlet + MySQL)

## O que é
Projeto Java (Maven) simples que fornece um front-end HTML e um servlet (`/api/users`) para criar, editar, buscar e deletar usuários.
Cada usuário tem: `id`, `name`, `phone`, `info`.

## Configuração (passo a passo)
1. **Copie este projeto** para a máquina onde você tem o NetBeans (VM do NetBeans).
2. **Abra no NetBeans**: `File` -> `Open Project...` -> selecione a pasta do projeto (onde está o `pom.xml`). NetBeans importa projeto Maven automaticamente.
3. **Ajuste o arquivo de conexão**: `src/main/resources/db.properties`. Substitua `<MYSQL_HOST>` por **o IP da VM do MySQL**. Ajuste `db.user` e `db.password` para o usuário e senha do MySQL.
   - Exemplo: `db.url=jdbc:mysql://192.168.56.101:3306/userdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC`
4. **Crie o banco de dados no MySQL (na outra VM)**:
   - Conecte ao MySQL e rode `sql/create_database.sql` incluído neste ZIP. Ele cria o banco `userdb` e a tabela `users`.
   - Comandos rápidos (na VM do MySQL):
     ```bash
     mysql -u root -p
     SOURCE /path/to/create_database.sql;
     ```
5. **Build & Run**:
   - No NetBeans: execute o projeto (Run). NetBeans geralmente usa o GlassFish ou Tomcat que você tem configurado.
   - Depois abra no navegador: `http://localhost:8080/user-management-webapp/` (a URL pode variar dependendo do container e da porta).
6. **Testar**: use o formulário para criar, buscar, editar e deletar usuários. Lembre-se de usar o IP da VM do MySQL no `db.properties`.

## SQL (já incluso)
Arquivo: `sql/create_database.sql`

-- fim do README
