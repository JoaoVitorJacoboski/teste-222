package app;

import java.sql.Connection;
import java.sql.DriverManager;

/*
 * CONFIGURAR AQUI: altere o IP, usuário e senha conforme sua VM do MySQL.
 * Exemplo de URL (substitua 192.168.1.100 pelo IP da VM do banco):
 *   jdbc:mysql://192.168.1.100:3306/cadastro?useTimezone=true&serverTimezone=UTC
 *
 * Observação: este projeto assume que o banco se chama 'cadastro' (conforme seu pedido).
 */

public class Conexao {
    public static Connection getConnection() {
        try {
            // ATENÇÃO: alterar os valores abaixo conforme sua infra
            String url = "jdbc:mysql://192.168.1.100:3306/cadastro?useTimezone=true&serverTimezone=UTC";
            String usuario = "root";
            String senha = "12345";

            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, usuario, senha);

        } catch (Exception e) {
            throw new RuntimeException("Erro na conexão: " + e.getMessage());
        }
    }
}
