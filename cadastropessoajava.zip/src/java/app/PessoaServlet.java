package app;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class PessoaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String acao = req.getParameter("acao");
        PessoaDAO dao = new PessoaDAO();

        if ("salvar".equals(acao)) {
            Pessoa p = montarPessoa(req);
            dao.salvar(p);
            resp.getWriter().println("Salvo com sucesso!");

        } else if ("buscar".equals(acao)) {
            String cpf = req.getParameter("cpf");
            Pessoa p = dao.buscar(cpf);

            if (p != null)
                resp.getWriter().println("Encontrado: " + p.getNome());
            else
                resp.getWriter().println("Pessoa não encontrada.");

        } else if ("deletar".equals(acao)) {
            String cpf = req.getParameter("cpf");
            dao.deletar(cpf);
            resp.getWriter().println("Deletado com sucesso!");

        } else if ("atualizar".equals(acao)) {
            Pessoa p = montarPessoa(req);
            dao.atualizar(p);
            resp.getWriter().println("Atualizado com sucesso!");
        }
    }

    private Pessoa montarPessoa(HttpServletRequest req) {
        String nome = req.getParameter("nome");
        String cpf = req.getParameter("cpf");
        String telefone = req.getParameter("telefone");
        String email = req.getParameter("email");
        String cep = req.getParameter("cep");
        String rua = req.getParameter("rua");
        int numero = Integer.parseInt(req.getParameter("numero"));

        return new Pessoa(nome, cpf, telefone, email, cep, rua, numero);
    }
}
