package app;

import java.sql.*;

public class PessoaDAO {

    public void salvar(Pessoa p) {
        String sql = "INSERT INTO pessoa (cpf, nome, telefone, email, cep, rua, numero) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getCpf());
            stmt.setString(2, p.getNome());
            stmt.setString(3, p.getTelefone());
            stmt.setString(4, p.getEmail());
            stmt.setString(5, p.getCep());
            stmt.setString(6, p.getRua());
            stmt.setInt(7, p.getNumero());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Pessoa buscar(String cpf) {
        String sql = "SELECT * FROM pessoa WHERE cpf=?";
        Pessoa p = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                p = new Pessoa(
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("telefone"),
                    rs.getString("email"),
                    rs.getString("cep"),
                    rs.getString("rua"),
                    rs.getInt("numero")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }

    public void deletar(String cpf) {
        String sql = "DELETE FROM pessoa WHERE cpf=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void atualizar(Pessoa p) {
        String sql = "UPDATE pessoa SET nome=?, telefone=?, email=?, cep=?, rua=?, numero=? WHERE cpf=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getTelefone());
            stmt.setString(3, p.getEmail());
            stmt.setString(4, p.getCep());
            stmt.setString(5, p.getRua());
            stmt.setInt(6, p.getNumero());
            stmt.setString(7, p.getCpf());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
