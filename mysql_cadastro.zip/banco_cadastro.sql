CREATE DATABASE IF NOT EXISTS cadastro;
USE cadastro;

CREATE TABLE IF NOT EXISTS pessoa (
    cpf VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100),
    telefone VARCHAR(20),
    email VARCHAR(100),
    cep VARCHAR(20),
    rua VARCHAR(100),
    numero INT
);
